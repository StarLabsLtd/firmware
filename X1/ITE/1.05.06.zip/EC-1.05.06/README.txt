Star Labs Firmware Update

Before updating your firmware, ensure your battery is charged to at least 50% and connected to the charger.

1. Format a USB Drive in FAT32 with MBR.

2. Extract the contents of the zip file to the USB drive

3. Boot the computer and press F7 to see the boot menu. Select UEFI:%your flash drive%

4. When the shell started, you should see a list of file systems available at the top. One of these with reference your USB, it is usually FS1:
4.1 Type FSX: X being the number of your USB drive
4.2 Type ls and confirm you can the correct files

5.1 Type flash.nsh
5.2 Your computer will shutdown. Turn it back on.



