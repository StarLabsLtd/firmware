echo -off
cls
set payload I5.cap

echo "*******************************************************************"
echo "************ StarLite Mk V Battery Full-Flow EC Debug *************"
echo "*******************************************************************"
echo " "
echo "This EC-only diagnostic capsule is for StarLite Mk V / I5."
echo "It keeps the 26.06 coreboot payload and updates only the EC FMAP region."
echo " "
echo "Press Enter to update firmware or press Q to quit."
pause
for %a run (0 10)
	if exist fs%a:CapsuleApp.efi then
		fs%a:
		CapsuleApp.efi %payload%
		reset
	endif
endfor
