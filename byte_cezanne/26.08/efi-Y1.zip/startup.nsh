echo -off
 cls
 set payload Y1.cap
 
 echo "*******************************************************************"
 echo "********************* BIOS & Firmware Update **********************"
 echo "*******************************************************************"
 echo " "
 echo "This update is for the Byte MkI. Installing on any other laptop will cause it not to start."
 echo " "
 echo "This update contains the following changes:"
 echo "General Updates:"
echo "* Added support for StarBook Mk VIII"
echo "* Added persistent embedded-controller diagnostics for post-reset fault analysis"
echo "* Added runtime controls for firmware settings"
echo ""
echo "New options:"
echo "* [Power Reporting] Option to not tell the OS that the system is not charging with AC connected"
echo "* [Automatic Start] Start automatically when a charger is connected, power is restored after a loss or never."
echo "* [Audio Device ID] Interim option to use the old audio IDs, required for Windows until all drivers are updated"
echo ""
echo "Security Updates:"
echo "* Improved TPM detection and event-log handoff"
echo "* Updated the Secure Boot revocation database"
echo ""
echo "Bug Fixes / Enhancements:"
echo "* Fixed regression with PCAT legacy interrupts"
echo "* Both ports can be used for empty or absent battery"
echo "* Fixed invalid battery capacity data being shown in firmware setup"
echo "* Reduced unnecessary boot delays searching for slow USB drives"
echo "* Switch to new audio codec IDs, to pick up linux quirks designed to microphone noise"
echo "* [StarBook Mk V] Switch to Software Connection Manager to work around linux bug"
echo "* [StarFighter Mk I] More power efficient GPIO config"
echo "* [StarBook Mk IVr2] More power efficient GPIO config"
 echo "Press Enter to update firmware or press Q to quit."
 pause
 for %a run (0 10)
 	if exist fs%a:CapsuleApp.efi then
 		fs%a:
 		CapsuleApp.efi %payload%
 		reset
 	endif
 endfor
