echo -off
 cls
 set payload L4.cap
 
 echo "*******************************************************************"
 echo "********************* BIOS & Firmware Update **********************"
 echo "*******************************************************************"
 echo " "
 echo "This update is for the LabTop MkIV. Installing on any other laptop will cause it not to start."
 echo " "
 echo "This update contains the following changes:"
 echo "General Updates: "
echo "* Added support for AMD Cezanne models (Byte Mk I and StarBook Mk VI)"
echo "* Added coreboot support for Byte Mk I and StarBook Mk VI-AMD"
echo ""
echo "New Options:"
echo "* Custom power profile controls for PL1, PL2, PL4, and CPU thermal throttle temperature"
echo "* Per-port PCIe power management controls"
echo "* HDA DSP firmware setup toggle"
echo ""
echo "Bug Fixes / Enhancements:"
echo "* Reduced false CPU throttling from charge-controller PROCHOT while preserving brown-out protection"
echo "* [StarFighter] Reduced touchpad startup delay and fixed touchpad settings not being applied"
echo "* [StarFighter] Improved Wi-Fi, Bluetooth, and touchpad setup handling"
echo "* [StarLite Mk V] Improved battery free operation"
 echo "Press Enter to update firmware or press Q to quit."
 pause
 for %a run (0 10)
 	if exist fs%a:CapsuleApp.efi then
 		fs%a:
 		CapsuleApp.efi %payload%
 		reset
 	endif
 endfor
