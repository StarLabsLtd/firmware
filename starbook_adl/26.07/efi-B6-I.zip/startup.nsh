echo -off
 cls
 set payload B6-I.cap
 
 echo "*******************************************************************"
 echo "********************* BIOS & Firmware Update **********************"
 echo "*******************************************************************"
 echo " "
 echo "This update is for the StarBook MkVI-Intel. Installing on any other laptop will cause it not to start."
 echo " "
 echo "This update contains the following changes:"
 echo "General Updates:"
echo "* Updated Intel microcode and Intel FSP binaries, including public IoT FSP builds where available"
echo "* Added capsule-on-disk handoff support, including AMD capsule update support"
echo "* Added runtime firmware setting support for safe options and Merlin EC persistent storage"
echo ""
echo "New Options:"
echo "* AC-connect power-on control"
echo "* IBECC support on supported platforms"
echo ""
echo "Security Updates:"
echo "* Enabled SMM BIOS write protection on StarLite Mk III/IV"
echo "* Improved TPM probing so TPM ACPI tables are only exposed for present TPMs"
echo "* Fixed TPM2 event log entry packing for better PCR reconstruction"
echo "* Hid Intel PTT when the Management Engine is disabled and added split FSP lockdown policy"
echo ""
echo "Bug Fixes / Enhancements:"
echo "* Charge limit settings now persist in EC storage and apply after full power-off (G3)"
echo "* [StarFighter] Touchpad report rate can now be applied at runtime"
echo "* Improved S4/S5 wake handling and ACPI Time and Alarm Device support"
echo "* Improved hibernation resume reliability when firmware wake alarms are enabled"
echo "* Fixed USB hub topology, Bluetooth disable, and USB-C data-device descriptions across supported boards"
echo "* Fixed Type-C DisplayPort VBT types and tolerated absent Thunderbolt aliases"
echo "* Improved low-battery and AC handling on Merlin EC boards"
echo "* Improved AMD Cezanne sleep, power-button, and GPIO IRQ handling"
echo "* Reduced unnecessary ACPI devices when hardware is absent or disabled"
 echo "Press Enter to update firmware or press Q to quit."
 pause
 for %a run (0 10)
 	if exist fs%a:CapsuleApp.efi then
 		fs%a:
 		CapsuleApp.efi %payload%
 		reset
 	endif
 endfor
