echo -off
 cls
 set payload B62-I.cap
 
 echo "*******************************************************************"
 echo "********************* BIOS & Firmware Update **********************"
 echo "*******************************************************************"
 echo " "
 echo "This update is for the StarBook MkVIr2-Intel. Installing on any other laptop will cause it not to start."
 echo " "
 echo "This update contains the following changes:"
 echo "General Updates: "
echo "* Added support for AMD Cezanne models (Byte Mk I and StarBook Mk VI)"
echo ""
echo "Bug Fixes / Enhancements:"
echo "* Improved capsule update reliability"
echo "* Fixed hibernation failures caused by inconsistent payload memory maps"
echo "* Ignored malformed OS-created UEFI variable records instead of blocking boot"
echo "* Avoided EDK2 serial port reinitialisation"
echo "* Dropped shell networking when networking support is disabled"
echo "* Disable TPM1"
echo "* Fixed PCR0 Reconstruction"
echo "* Improved HiDPI logo, console text, and graphics handoff handling"
echo "* Reduced false CPU throttling from charge-controller PROCHOT while preserving brown-out protection"
echo "* Improved low battery handling with a warning splash, adjusted wake threshold, and graceful critical battery shutdown"
echo "* Dynamically set PL4 from charger and battery state"
echo "* Fixed memory speed changes reusing stale training data"
echo "* Fixed ANX7447 dead battery charging"
echo "* Added Fn+F hot key for 100 0.000000an duty"
echo "* Stored the serial number in firmware variables"
echo "* [StarFighter] Reduced touchpad startup delay and fixed touchpad settings not being applied"
echo "* [StarLite Mk V] Improved battery free operation and fixed auto-rotation on Ubuntu"
echo "* [StarBook MkVIr2-Intel] Fixed blue sleep LED breathing"
echo "* Improved keyboard scan debounce to reduce ghosting and missed keys"
 echo "Press Enter to update firmware or press Q to quit."
 pause
 for %a run (0 10)
 	if exist fs%a:CapsuleApp.efi then
 		fs%a:
 		CapsuleApp.efi %payload%
 		reset
 	endif
 endfor
