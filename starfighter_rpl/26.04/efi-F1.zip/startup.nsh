echo -off
 cls
 set payload F1.cap
 
 echo "*******************************************************************"
 echo "********************* BIOS & Firmware Update **********************"
 echo "*******************************************************************"
 echo " "
 echo "This update is for the StarFighter MkI. Installing on any other laptop will cause it not to start."
 echo " "
 echo "This update contains the following changes:"
 echo "General Updates:"
echo "* Added capsule update support, with graphical update progress, more reliable flashing, and better preservation of existing settings and unchanged firmware data"
echo "* Reworked the firmware setup menu into a cleaner Settings-style layout, with clearer Boot and Security sections"
echo ""
echo "New Options:"
echo "* Configurable boot timeout"
echo "* Digital Signal Processor"
echo "* [StarFighter] Touchpad Vibration Intensity"
echo "* [StarFighter] Touchpad Click Force"
echo "* [StarFighter] Touchpad Release Force"
echo "* [StarFighter] Touchpad Tracking Speed"
echo "* [StarFighter] Speaker Idle"
echo ""
echo "Security Updates:"
echo "* Added BIOS password protection"
echo "* Added TCG OPAL storage support for compatible NVMe drives, including S3 unlock support"
echo ""
echo "Bug Fixes / Enhancements:"
echo "* Added better HiDPI scaling in firmware setup and improved graphics handoff, helping hibernation (S4) behave more reliably"
echo "* Corrected panel timing values against panel datasheets across current Star Labs platforms"
echo "* Increased PWM frequencies across supported boards to reduce flicker"
echo "* Added staged NVMe power sequencing on supported platforms so third-party and slower-to-initialize drives initialise more reliably"
echo "* [StarFighter] Enabled the card reader in firmware"
echo "* [StarLite Mk V / Horizon] Increased speaker output configuration to the intended 2.5W path"
echo "* Improved keyboard scan debounce handling so new key presses are detected more consistently"
echo "* Improved S3 power LED breathing behaviour for smoother and more consistent transitions"
echo "* Simplified reduced-brightness handling for the LEDs"
echo "* [Byte Mk III] Fix fan curve setting"
 echo "Press Enter to update firmware or press Q to quit."
 pause
 for %a run (0 10)
 	if exist fs%a:CapsuleApp.efi then
 		fs%a:
 		CapsuleApp.efi %payload%
 		reset
 	endif
 endfor
